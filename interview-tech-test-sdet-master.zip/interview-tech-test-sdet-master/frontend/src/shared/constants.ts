export const SEED_ARTISTS = [
  "5dfZ5uSmzR7VQK0udbAVpf",
  "1LEtM3AleYg1xabW6CRkpi",
  "06HL4z0CvFAxyc27GXpf02",
  "1uNFoZAHBGtllmzznpCI3s",
  "5FWPIKz9czXWaiNtw45KQs",
].join(",");

export const TOP_PLAYLISTS = [
  "37i9dQZF1DX0F4i7Q9pshJ",
  "37i9dQZF1DXcBWIGoYBM5M",
  "37i9dQZEVXbMDoHDwVN2tF",
  "4hOKQuZbraPDIfaGbM3lKI",
  "1KNl4AYfgZtOVm9KHkhPTF",
  "5iwkYfnHAGMEFLiHFFGnP4",
  "37i9dQZEVXbLRQDuF5jeBp",
  "37i9dQZF1DX7Jl5KP2eZaS",
  "37i9dQZF1DX18jTM2l2fJY",
  "4BDcwKv9RSKKJ1bCVgfhNn",
];
