import Spotify from "spotify-web-api-js";

const client = new Spotify();

export default client;
