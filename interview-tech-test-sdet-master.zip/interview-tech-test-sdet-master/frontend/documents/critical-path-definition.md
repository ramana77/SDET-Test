# 🛣️ The Critical Path Defined 

Our App has been made to allow users to search for thier artists, specifically:

- The New Releases content is displayed on the Home page.
- Use the search feature in the top right to search for an artist.
- Find your artist and follow through to one of their albums.
- Confirm that album details and songs are displayed within the album.
