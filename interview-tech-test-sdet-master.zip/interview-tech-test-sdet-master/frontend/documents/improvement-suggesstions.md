# 💪 Improvement Suggestions

As mentioned in the readme we understand you won't have time to implement all the possible improvements within your tech assessment, but we would like to hear your throughs on the improvements you would add if this was your actual teams product.

For example explain:
- What is the improvement
- How would you implement it
- Why would this be an improvement

...




