# Spring Boot application example SAS

This is an application that manages a database of a bowling league or season, with the users of the service and tournaments.
bowling league or season, with the users of the service and the available tournaments (items).
available (items). The users make subscriptions (orders) to the * service to register for the championships.
service to register for tournaments.

You will find in a comment on the kingPin test file a bean of code you can use to populate the database. Feel free to use it if need it.

Good luck!


![cat pic](https://i.pinimg.com/736x/fe/bb/d4/febbd478ad268919fbf80b0b5e069165.jpg)
