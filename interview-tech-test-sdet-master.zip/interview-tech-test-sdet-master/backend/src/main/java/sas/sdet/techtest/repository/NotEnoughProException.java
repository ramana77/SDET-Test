package sas.sdet.techtest.repository;

public class NotEnoughProException extends Exception {
    private static final long serialVersionUID = 1L;
}
